
#include "../include/reserva.h"

struct rep_reserva {
};

TReserva crearTReserva(TSocio socio, TLibro libro){
  return NULL;
}

void imprimirTReserva(TReserva reserva){
}

void liberarTReserva(TReserva &reserva){
}

TSocio socioTReserva(TReserva reserva){
  return NULL;
}

TLibro libroTReserva(TReserva reserva){
  return NULL;
}

TReserva copiarTReserva(TReserva reserva){
  return NULL;
}

void liberarTReservaSoloEstructura(TReserva &reserva) {
}
