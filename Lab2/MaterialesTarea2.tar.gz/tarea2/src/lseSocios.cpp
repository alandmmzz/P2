
#include "../include/lseSocios.h"

struct rep_lseSocios {
};

TLSESocios crearTLSESociosVacia(){
    return NULL;
}

bool esVaciaTLSESocios(TLSESocios lseSocios){
	return false;
}

void imprimirTLSESocios(TLSESocios lseSocios){
}

void liberarTLSESocios(TLSESocios &lseSocios){
}

void insertarTLSESocios(TLSESocios &lseSocios, TSocio socio){
}

bool existeSocioTLSESocios(TLSESocios lseSocios, int ci){
	return false;
}

TSocio obtenerSocioTLSESocios(TLSESocios lseSocios, int ci){
    return NULL;
}

TSocio obtenerNesimoTLSESocios(TLSESocios lseSocios, int n){
	return NULL;
}

nat cantidadTLSESocios(TLSESocios lseSocios){
	return 0;
}

void removerSocioTLSESocios(TLSESocios &lseSocios, int ci){
}