
#include "../include/prestamo.h"

struct rep_prestamo {
};

TPrestamo crearTPrestamo(TSocio socio, TLibro libro, TFecha fechaRetiro){
  return NULL;
}
 
void imprimirTPrestamo(TPrestamo prestamo){
}

void liberarTPrestamo(TPrestamo &prestamo){
}

TSocio socioTPrestamo(TPrestamo prestamo){
  return NULL;
}
 
TFecha fechaRetiroTPrestamo(TPrestamo prestamo){
  return NULL;
}

TFecha fechaDevolucionTPrestamo(TPrestamo prestamo){
  return NULL;
}

TLibro libroTPrestamo(TPrestamo prestamo){
  return NULL;
}

bool fueRetornadoTPrestamo(TPrestamo prestamo){
  return false;
}

void actualizarFechaDevolucionTPrestamo(TPrestamo prestamo, TFecha fechaDevolucion){
}

TPrestamo copiarTPrestamo(TPrestamo prestamo){
  return NULL;
}