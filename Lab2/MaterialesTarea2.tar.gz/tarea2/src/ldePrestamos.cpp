#include "../include/ldePrestamos.h"

struct nodoDoble{
};

struct rep_ldePrestamos {
};

TLDEPrestamos crearTLDEPrestamosVacia(){
    return NULL;
}

void insertarTLDEPrestamos(TLDEPrestamos &ldePrestamos, TPrestamo prestamo){
}

void liberarTLDEPrestamos(TLDEPrestamos &ldePrestamos){
}

void imprimirTLDEPrestamos(TLDEPrestamos ldePrestamos){
}

void imprimirInvertidoTLDEPrestamos(TLDEPrestamos ldePrestamos){
}

nat cantidadTLDEPrestamos(TLDEPrestamos ldePrestamos){
    return 0;
}

TPrestamo obtenerPrimeroTLDEPrestamos(TLDEPrestamos ldePrestamos){
    return NULL;
}

TPrestamo obtenerUltimoTLDEPrestamos(TLDEPrestamos ldePrestamos){
    return NULL;
}

TPrestamo obtenerNesimoTLDEPrestamos(TLDEPrestamos &ldePrestamos, int n){
    return NULL;
}

// criterio = 0 -> prestamos retornados
// criterio = 1 -> prestamos no retornados
TLDEPrestamos filtrarPrestamosTLDEPrestamos(TLDEPrestamos &ldePrestamos, int criterio){
    return NULL;
}


