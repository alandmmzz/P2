#include "../include/tablaReserva.h"

// Se debe implementar mediante una tabla de dispersión abierta (hash)

struct rep_tablaTablaReserva {
};


TTablaReserva crearTTablaReserva(int max, int N){
    return NULL;
}


void insertarTTablaReserva(TTablaReserva &tabla, int isbn, TReserva reserva){

}


bool perteneceTTablaReserva(TTablaReserva tabla, int ciSocio, int isbnLibro) {
    return false;
}


TColaDePrioridadReservas obtenerReservaTTablaReserva(TTablaReserva tabla, int isbn){
    return NULL;
}

TReserva obtenerSigReservaTTablaReserva(TTablaReserva tabla, int isbn){
    return NULL;
}

void liberarTTablaReserva(TTablaReserva &tabla){

}
